// actionTypes.js
export const ADD_INVOICE = 'ADD_INVOICE';
export const EDIT_INVOICE = 'EDIT_INVOICE';
export const VIEW_INVOICE = 'VIEW_INVOICE';
export const DELETE_INVOICE = 'DELETE_INVOICE';
export const UPDATE_INVOICE = 'UPDATE_INVOICE';
export const UPDATE_VIEW_INVOICE = 'UPDATE_VIEW_INVOICE';
